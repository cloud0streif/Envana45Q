"""Test suite for data producer."""
