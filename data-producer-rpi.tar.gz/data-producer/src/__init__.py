"""BME280 Data Producer - Fake sensor data generator."""

__version__ = "0.1.0"
